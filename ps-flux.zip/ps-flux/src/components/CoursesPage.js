import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import { getCourses } from "../api/courseApi";
import CourseList from "./CourseList";
import courseStore from '../stores/courseStore';
import { loadCourses, deleteCourse } from '../actions/courseActions';

function CoursesPage() {

  // const [courses, setCourses] = useState([]);
  const [courses, setCourses] = useState(courseStore.getCourses());

  useEffect(() => {
    courseStore.addChangeListener(onChange);
    // getCourses().then(_courses => setCourses(_courses));
    // setCourses(courseStore.getCourses());
    if (courseStore.getCourses().length === 0) loadCourses();

    return () => courseStore.removeChangeListener(onChange); // cleanup on unmount
  }, []); // Second argument -- Empty array means run only once.

  function onChange() {
    setCourses(courseStore.getCourses())
  }

  /*renderRow(course) {
    return (
      <tr>
        <td>{course.title}</td>
        <td>{course.authorId}</td>
        <td>{course.category}</td>
      </tr>
    );
  }*/

  //render() {
    return (
      <>
      <h2>Courses</h2>
      <Link className="btn btn-primary" to="/course">Add Course</Link>
      <CourseList courses={courses} deleteCourse={deleteCourse}/>
      </>
    );
  //}
}

export default CoursesPage;