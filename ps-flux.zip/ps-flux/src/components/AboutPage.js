import React from 'react';

class AboutPage extends React.Component {
  render() {
    return <h2>About</h2>
  }
}

export default AboutPage;